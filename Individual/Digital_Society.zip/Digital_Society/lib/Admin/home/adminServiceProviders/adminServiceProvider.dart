import 'package:digital_society1/Admin/home/adminServiceProviders/adminServiceView.dart';
import 'package:digital_society1/User/home/ServiceProviders.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class adminServiceProvider extends StatefulWidget {
  const adminServiceProvider({Key? key}) : super(key: key);

  @override
  State<adminServiceProvider> createState() => _adminServiceProviderState();
}

class _adminServiceProviderState extends State<adminServiceProvider> {
  TextEditingController category = TextEditingController();
  TextEditingController name = TextEditingController();
  TextEditingController mobileNo = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Service Provider", style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.deepPurple,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('images/background_image.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Container(

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 100),
                Row(
                  // crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 30),
                      height: 50,
                      width: 100,
                      child: Text(
                        "Category:",
                        style: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      margin: EdgeInsets.only(top: 1),
                      height: 50,
                      width: 200,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.deepPurple,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: TextField(
                        controller: category,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Plumber, Electrician, etc..",
                          contentPadding: EdgeInsets.only(left: 20, top: 14, right: 20, bottom: 10),
                        ),
                        keyboardType: TextInputType.multiline,
                        maxLines: null,
                        expands: true,
                      ),
                    ),
                  ],
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 20),
                      height: 50,
                      width: 100,
                      child: Text(
                        "Name:",
                        style: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                    ),
                    SizedBox(width: 10),
                    Container(
                      height: 50,
                      width: 200,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.deepPurple,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: TextField(
                        controller: name,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(left: 20, top: 14, right: 20, bottom: 10),
                        ),
                        keyboardType: TextInputType.multiline,
                        maxLines: null,
                        expands: true,
                      ),
                    ),
                  ],
                ),

                Row(
                  // crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 20),
                      height: 50,
                      width: 100,
                      child: Text(
                        "Mobile No:",
                        style: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold, fontSize: 18,),
                      ),
                    ),
                    SizedBox(width: 10,),
                    Container(
                      height: 50,
                      width: 200,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.deepPurple,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: TextField(
                        textAlign: TextAlign.start,
                        controller: mobileNo,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(left: 20, top: 14, right: 20, bottom: 10),
                        ),
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      print("Clicked");
                      var url = Uri.parse("https://begrimed-executions.000webhostapp.com/digital_society/service_providers/insert.php");
                      http.post(
                        url,
                        body: {
                          "category": category.text.toString(),
                          "name": name.text.toString(),
                          "mobileNo": mobileNo.text.toString(),
                        },
                      );
                      category.text = "";
                      name.text = "";
                      mobileNo.text = "";
                      print("Data sent successfully");
                    });
                    Navigator.push(context, MaterialPageRoute(builder: (context) => ServiceProviders()));
                  },
                  child: Text("Send", style: TextStyle(color: Colors.white),),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                SizedBox(height: 10,),
                ElevatedButton(
                    onPressed: ()
                    {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => adminServiceView(list: category, index: 0)));
                    },
                    child: Text("View Service Providers Page", style: TextStyle(color: Colors.white),),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple,
                      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
