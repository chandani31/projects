import 'package:digital_society1/Admin/home/adminMembers.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class edit_Service extends StatefulWidget
{

  edit_Service();


  @override
  _edit_ServiceState createState() => _edit_ServiceState();

}

class _edit_ServiceState  extends State<edit_Service>
{
  TextEditingController Category = TextEditingController();
  TextEditingController Name = TextEditingController();
  TextEditingController MobileNo = TextEditingController();


  @override
  void initState()
  {
    super.initState();
  }


  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar:  AppBar(

        title: Text("Edit Data"),
      ),

      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('images/background_image.jpg'),
              fit: BoxFit.cover,
            )
        ),
        child: ListView(
          children: [
            TextFormField(
              textAlign: TextAlign.start,
              controller: Category,
              decoration: InputDecoration(
                border: InputBorder.none,

                icon: Icon(Icons.person_outline_outlined, color: Colors.black,),
                hintText: "Enter Category",
                contentPadding: EdgeInsets.symmetric(vertical: 7),

              ),
              keyboardType: TextInputType.text,
              onFieldSubmitted: (value) {

              },
              validator: (value)
              {
                if(value!.isEmpty)
                {
                  return "Please Enter Category";
                }
                return null;
              },
            ),

            TextFormField(
              textAlign: TextAlign.start,
              controller: Name,
              decoration: InputDecoration(
                border: InputBorder.none,

                icon: Icon(Icons.perm_identity_outlined, color: Colors.black,),
                hintText: "Enter Name",
                contentPadding: EdgeInsets.symmetric(vertical: 7),

              ),
              keyboardType: TextInputType.text,
              onFieldSubmitted: (value) {

              },
              validator: (value)
              {
                if(value!.isEmpty)
                {
                  return "Please Enter Name";
                }
                return null;
              },
            ),

            TextFormField(
              textAlign: TextAlign.start,
              controller: MobileNo,
              decoration: InputDecoration(
                border: InputBorder.none,

                icon: Icon(Icons.phone_outlined, color: Colors.black,),
                hintText: "Mobile No",
                contentPadding: EdgeInsets.symmetric(vertical: 7),

              ),
              keyboardType: TextInputType.number,
              onFieldSubmitted: (value) {

              },
              validator: (value)
              {
                if(value!.isEmpty || !RegExp(r"^\d{10}$").hasMatch(value))
                {
                  return "Please Enter Valid Mobileno";
                }
                return null;
              },
            ),

            MaterialButton(
              child: Text("Save"),
              onPressed: (){
                editData();
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (BuildContext context)=> adminMembers()),
                );
              },
            )
          ],
        ),
      ),
    );
  }

  void editData()
  {
    var url =Uri.parse("https://begrimed-executions.000webhostapp.com/digital_society/register/register_view.php");
    http.post(url,body: {

      'Category': Category.text.toString(),
      'Name': Name.text.toString(),
      'MobileNo': MobileNo.text.toString(),
    });


  }

}