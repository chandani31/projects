import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class adminProfilePage extends StatefulWidget {
  const adminProfilePage({Key? key}) : super(key: key);

  @override
  State<adminProfilePage> createState() => _adminProfilePageState();
}

class _adminProfilePageState extends State<adminProfilePage> {
  TextEditingController Name = TextEditingController();
  TextEditingController Address = TextEditingController();
  TextEditingController Email = TextEditingController();
  TextEditingController MobileNo = TextEditingController();
  TextEditingController Payment = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Bills", style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.deepPurple,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('images/background_image.jpg'),
              fit: BoxFit.cover,
              repeat: ImageRepeat.repeat,
            ),
          ),
          height: MediaQuery.of(context).size.height*0.9,
          child: Center(
            child: Container(

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 100),
                  Row(
                    // crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 30),
                        height: 50,
                        width: 100,
                        child: Text(
                          "Name:",
                          style: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                      ),
                      SizedBox(width: 10),
                      Container(
                        margin: EdgeInsets.only(top: 1),
                        height: 50,
                        width: 200,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.deepPurple,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: TextField(
                          controller: Name,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "abc",
                            contentPadding: EdgeInsets.only(left: 20, top: 14, right: 20, bottom: 10),
                          ),
                          keyboardType: TextInputType.multiline,
                          maxLines: null,
                          expands: true,
                        ),
                      ),
                    ],
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 20),
                        height: 50,
                        width: 100,
                        child: Text(
                          "Address",
                          style: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                      ),
                      SizedBox(width: 10),
                      Container(
                        height: 50,
                        width: 200,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.deepPurple,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: TextField(
                          controller: Address,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "WingNo(101)",
                            contentPadding: EdgeInsets.only(left: 20, top: 14, right: 20, bottom: 10),
                          ),
                          keyboardType: TextInputType.multiline,
                          maxLines: null,
                          expands: true,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 20),
                        height: 50,
                        width: 100,
                        child: Text(
                          "Email",
                          style: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                      ),
                      SizedBox(width: 10),
                      Container(
                        height: 50,
                        width: 200,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.deepPurple,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: TextField(
                          controller: Email,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "abc@gmail.com",
                            contentPadding: EdgeInsets.only(left: 20, top: 14, right: 20, bottom: 10),
                          ),
                          keyboardType: TextInputType.multiline,
                          maxLines: null,
                          expands: true,
                        ),
                      ),
                    ],
                  ),

                  Row(
                    // crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 20),
                        height: 50,
                        width: 100,
                        child: Text(
                          "Mobile No:",
                          style: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold, fontSize: 18,),
                        ),
                      ),
                      SizedBox(width: 10,),
                      Container(
                        height: 50,
                        width: 200,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.deepPurple,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: TextField(
                          textAlign: TextAlign.start,
                          controller: MobileNo,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "1234567899",
                            contentPadding: EdgeInsets.only(left: 20, top: 14, right: 20, bottom: 10),
                          ),
                          keyboardType: TextInputType.number,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 20),
                        height: 50,
                        width: 100,
                        child: Text(
                          "Payment",
                          style: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                      ),
                      SizedBox(width: 10),
                      Container(
                        height: 50,
                        width: 200,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.deepPurple,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: TextField(
                          controller: Payment,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Pending(1000) or Padid(1000)",
                            contentPadding: EdgeInsets.only(left: 20, top: 14, right: 20, bottom: 10),
                          ),
                          keyboardType: TextInputType.multiline,
                          maxLines: null,
                          expands: true,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        print("Clicked");
                        var url = Uri.parse("https://begrimed-executions.000webhostapp.com/digital_society/my_bills/insert.php");
                        http.post(
                          url,
                          body: {
                            "Name": Name.text.toString(),
                            "Address": Address.text.toString(),
                            "Email": Email.text.toString(),
                            "MobileNo": MobileNo.text.toString(),
                            "Payment": Payment.text.toString(),
                          },
                        );
                        Name.text = "";
                        Address.text = "";
                        Email.text = "";
                        MobileNo.text = "";
                        Payment.text = "";
                        print("Data sent successfully");
                      });
                    },
                    child: Text("Send", style: TextStyle(color: Colors.white),),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple,
                      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
