import 'package:digital_society1/User/bottom_navigation/profilePage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../adminHome.dart';
import 'admin_profile_page.dart';

class adminMainScreen extends StatefulWidget {
  const adminMainScreen({super.key});

  @override
  State<adminMainScreen> createState() => _adminMainScreenState();
}

class _adminMainScreenState extends State<adminMainScreen>
{
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    adminhomePage(),
    adminProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.deepPurple,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.grey,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Profile",
          ),
        ],
      ),
    );
  }

  void _onItemTapped(int value) {
    setState(() {
      _selectedIndex = value;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _selectedIndex = 0;
  }
}
