import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class adminVisitors extends StatefulWidget {
  @override
  adminVisitorsState createState() => adminVisitorsState();
}

class adminVisitorsState extends State<adminVisitors> {
  late List list;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Visitors",
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('images/background_image.jpg'),
                repeat: ImageRepeat.repeat,
                fit: BoxFit.fill,
              ),
            ),
          ),
          Center(
            child: FutureBuilder<List>(
              future: getdetail(),
              builder: (ctx, ss) {
                if (ss.hasData) {
                  return Items(
                    list: ss.data!,
                    makePhoneCall: _makePhoneCall,
                  );
                }
                if (ss.hasError) {
                  print('Network Not Found');
                }

                return CircularProgressIndicator();
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<List> getdetail() async {
    var response = await http.get(Uri.parse(
        "https://begrimed-executions.000webhostapp.com/digital_society/register/register_view.php"));
    return jsonDecode(response.body);
  }

  void _makePhoneCall(String phoneNumber) async {
    String telScheme = 'tel:$phoneNumber';
    if (await canLaunch(telScheme)) {
      await launch(telScheme);
    } else {
      throw 'Could not launch $telScheme';
    }
  }

}

class Items extends StatelessWidget {
  final List list;
  final Function(String) makePhoneCall;

  Items({required this.list, required this.makePhoneCall});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: list.length,
      itemBuilder: (ctx, i) {
        return Container(
          padding: EdgeInsets.all(5),
          margin: EdgeInsets.only(top: 10, left: 15, right: 15, bottom: 10),
          height: 135,
          width: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: Colors.deepPurple.withOpacity(0.7),
                spreadRadius: 3,
                blurRadius: 3,
                offset: Offset(0, 2), // changes the position of the shadow
              ),
            ],
          ),
          child: ListTile(
            title: Row(
              children: [
                Text(
                  "${list[i]['FirstName']} ${list[i]['LastName']}",
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            subtitle: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 110,
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("MobileNo: ${list[i]['MobileNo']}",
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      Text("Address(Wing): ${list[i]['Address']}",
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      Text("Email: ${list[i]['Email']}",
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  onPressed: ()
                  {
                    final phoneNumber = list[i]['MobileNo']?.toString() ?? ''; // Use 'MobileNo' instead of 'MobileNumber'
                    print('Item data: ${list[i]}');
                    if (phoneNumber.isNotEmpty) {
                      makePhoneCall(phoneNumber); // Call the callback function
                    } else {
                      print('Phone number not available');
                    }
                  },
                  icon: Icon(Icons.call, color: Colors.white,),),
              ],
            ),
          ),
        );
      },
    );
  }
}
