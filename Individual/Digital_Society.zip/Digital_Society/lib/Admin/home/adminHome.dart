import 'package:app_settings/app_settings.dart';
import 'package:digital_society1/Admin/home/adminComplaints.dart';
import 'package:digital_society1/Admin/home/adminEvents.dart';
import 'package:digital_society1/Admin/home/adminNoticeBoard/adminNoticeBoard.dart';
import 'package:digital_society1/Admin/home/adminParking/adminParking.dart';
import 'package:digital_society1/Admin/home/adminServiceProviders/adminServiceProvider.dart';
import 'package:digital_society1/Admin/home/adminVisitors.dart';
import 'package:digital_society1/User/constants.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../User/login/login.dart';
import 'adminMembers.dart';
import 'adminPolls.dart';
import 'adminSOS.dart';

class adminhomePage extends StatefulWidget {
  adminhomePage({super.key});

  @override
  State<adminhomePage> createState() => _adminhomePageState();
}

class _adminhomePageState extends State<adminhomePage>
{
  late SharedPreferences logindata;

  @override
  void initState() {
    super.initState();
    initializeSharedPreferences();
  }

  void initializeSharedPreferences() async {
    logindata = await SharedPreferences.getInstance();
  }

  List<String> names =
  [
    membersName,
    noticeBoardName,
    // name3,
    eventsName,
    visitorsName,
    serviceProvidersName,
    // name7,
    parkingName,
    sosName,
    complaintsName,
    // name11,
    pollsName,
  ];

  List<String> icons =
  [
    memberIcon,
    noticeBoardIcon,
    // icon3,
    eventsIcon,
    visitorsIcon,
    serviceProvidersIcon,
    // icon7,
    parkingIcon,
    sosIcon,
    complaintsIcon,
    // icon11,
    pollsIcon,
  ];

  late List<String> jsonData;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      appBar: AppBar(title: Text("Smart Society", style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.deepPurple,
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          IconButton(
              onPressed: () async{
                await logindata.remove('login');
                Navigator.pushReplacement(context,
                    new MaterialPageRoute(builder: (context) => LoginPage()));
              }, icon: Icon(Icons.logout, color: Colors.white,)),
        ],
      ),

      drawer: Drawer(surfaceTintColor: Colors.white,
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            const UserAccountsDrawerHeader(
              decoration: BoxDecoration(color: Colors.white),
              accountName: Text("Email",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              currentAccountPicture: CircleAvatar(
                radius: 80.0, // Adjust the size as needed
                backgroundImage: AssetImage("images/members.png"),
                backgroundColor: Colors.deepPurple,
              ),
              accountEmail: Text("Email"),
            ),
            ListTile(
              leading: Icon(
                Icons.photo_library_rounded,
                color: Colors.black,
              ),
              title: const Text(
                'Images', style: TextStyle(color: Colors.black),),
              onTap: () {
                // Navigator.push(context, MaterialPageRoute(builder: (context) =>
                //     adminEvents(category_name: category_name, imagePath: '',)));
              },
            ),
            ListTile(
              leading: Icon(
                Icons.archive,
                color: Colors.black,
              ),
              title: const Text(
                'Archieved', style: TextStyle(color: Colors.black),),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Nothing is Archieved")));
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.delete,
                color: Colors.black,
              ),
              title: const Text(
                'Trash', style: TextStyle(color: Colors.black),),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Nothing is Deleted")));
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.settings,
                color: Colors.black,
              ),
              title: const Text(
                'Settings', style: TextStyle(color: Colors.black),),
              onTap: () {
                AppSettings.openAppSettings();
                Navigator.pop(context); // Close the drawer if needed
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(0),
              child: Image.asset("images/home.jpg"),
            ),
            SizedBox(height: 5,),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  color: Colors.deepPurple,
                  child: GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 7.0,
                      mainAxisSpacing: 7.0,
                      childAspectRatio: 0.9,
                    ),
                    itemCount: icons.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(
                        onTap: () async
                        {
                          switch (index) {
                            case 0:
                              if (names[index] == membersName &&
                                  icons[index] == memberIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => adminMembers()));
                              }
                              break;
                            case 1:
                              if (names[index] == noticeBoardName &&
                                  icons[index] == noticeBoardIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => adminNoticeBoard()));
                              }
                              break;
                            case 5:
                              if (names[index] == parkingName &&
                                  icons[index] == parkingIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => adminParking()));
                              }
                              break;
                            case 2:
                              if (names[index] == eventsName &&
                                  icons[index] == eventsIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => adminEvents()));
                              }
                              break;
                            case 4:
                              if (names[index] == serviceProvidersName &&
                                  icons[index] == serviceProvidersIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => adminServiceProvider()));
                              }
                              break;
                            case 3:
                              if (names[index] == visitorsName &&
                                  icons[index] == visitorsIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => adminVisitors()));
                              }
                              break;
                            case 7:
                              if (names[index] == complaintsName &&
                                  icons[index] == complaintsIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => adminComplaints()));
                              }
                              break;
                            case 8:
                              if (names[index] == pollsName &&
                                  icons[index] == pollsIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => adminPolls()));
                              }
                            case 6:
                              if (names[index] == sosName &&
                                  icons[index] == sosIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => adminSOS()));
                              }

                            default:
                            // Handle default case if needed
                          }

                        },

                        child: Column(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4.0),
                              child: Container(
                                alignment: Alignment.center,
                                height: 120,
                                width: 200,
                                color: Colors.white,
                                child: Center(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Container(
                                          height: 60, // Adjust the height of the image
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: AssetImage(icons[index]),
                                              fit: BoxFit.contain, // Adjust the fit to contain the image within the container
                                            ),
                                          ),
                                        ),
                                        Text(names[index],
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    )
                                ),
                              ),
                            ),
                          ],
                        ),
                        // Replace with your actual item widget
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
