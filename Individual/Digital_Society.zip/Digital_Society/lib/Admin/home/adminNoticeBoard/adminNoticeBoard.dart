import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class adminNoticeBoard extends StatefulWidget {

  @override
  State<adminNoticeBoard> createState() => _adminNoticeBoardState();
}

class _adminNoticeBoardState extends State<adminNoticeBoard> {
  @override

  TextEditingController text = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Notice", style: TextStyle(color: Colors.white),),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
      ),
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('images/background_image.jpg'),
                fit: BoxFit.cover,
                repeat: ImageRepeat.repeat
            )
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // SizedBox(height: 50,),
              Container(
                height: 220,
                width: 350,
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.deepPurple,
                    width: 2.0,
                  ),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextField(
                  controller: text,
                  decoration: InputDecoration(
                    labelText: "Enter Message",
                    labelStyle: TextStyle(color: Colors.deepPurple),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.only(
                        left: 20, top: 20, right: 20, bottom: 10),
                  ),
                  keyboardType: TextInputType.multiline,
                  maxLines: null,
                  expands: true,
                ),
              ),
              SizedBox(height: 10,),

              ElevatedButton(
                onPressed: () {
                  setState(() {
                    print("Clicked");
                    var url = Uri.parse("https://begrimed-executions.000webhostapp.com/digital_society/notice_board/insert.php");
                    http.post(
                      url,
                      body: {
                        "text": text.text.toString(),
                      },
                    );
                    text.text = "";
                    print("Data sent successfully");
                  });
                },
                child: Text("Send", style: TextStyle(color: Colors.white),),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple),
              ),
            ],
          ),
        ),
      ),
    );
  }
}