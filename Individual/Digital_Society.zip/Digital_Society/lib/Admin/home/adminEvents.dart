import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class adminEvents extends StatefulWidget {
  @override
  adminEventsState createState() => adminEventsState();
}

class adminEventsState extends State<adminEvents>
{
  late List<Map<String, dynamic>> list;

  List<String> images = [
    "https://begrimed-executions.000webhostapp.com/images/diwali.jpg",
    "https://begrimed-executions.000webhostapp.com/images/ganesh_chaturthi.jpg",
    "https://begrimed-executions.000webhostapp.com/images/holi.jpg",
    "https://begrimed-executions.000webhostapp.com/images/janmashtami.jpg",
    "https://begrimed-executions.000webhostapp.com/images/makarsankranti.jpg",
    "https://begrimed-executions.000webhostapp.com/images/navratri.jpg",
    "https://begrimed-executions.000webhostapp.com/images/ram_navami.jpg",
    "https://begrimed-executions.000webhostapp.com/images/republic_day.jpg",
  ];

  List<String> names = [
    "Diwali",
    "Ganesh Chaturthi",
    "Holi",
    "Janmashtami",
    "Makarsankranti",
    "Navratri",
    "Ramavami",
    "Republic day",
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    list = List.generate(images.length, (index)
    {
      return {
        'image': images[index],
        'name': names[index],
      };
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Events",
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('images/background_image.jpg'),
            repeat: ImageRepeat.repeat,
            fit: BoxFit.fill,
          ),
        ),
        child: Center(
          child: Column(
            children: [
              SizedBox(height: 30,),
              Text("We Celebrate Events Like...", style: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold, fontSize: 18),),
              SizedBox(height: 30,),
              Expanded(
                child: GridView.builder(
                  itemCount: list.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 7.0,
                    mainAxisSpacing: 7.0,
                    childAspectRatio: 0.9,),
                  itemBuilder: (context, index)
                  {
                    return Container(
                      height: MediaQuery.of(context).size.height*0.6,
                      width: MediaQuery.of(context).size.width*0.6,
                      child: Column(
                        children: [
                          Container(
                              height: 150,
                              width: 150,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.deepPurple,
                              ),
                              child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15),
                                  child: Image.network("${list[index]['image']}", height: 150, width: 150, fit: BoxFit.cover,))),
                          Text("${list[index]['name']}", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.deepPurple),),
                        ],
                      ),
                    );
                  },
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}