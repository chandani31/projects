import 'package:digital_society1/User/bottom_navigation/mainScreen.dart';
import 'package:digital_society1/User/home/home.dart';
import 'package:digital_society1/User/login/login.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;


enum GenderSelect {Male , Female}
class RegistrationPage extends StatefulWidget
{
  @override
  RegistrationState createState() => RegistrationState();


}

class RegistrationState extends State<RegistrationPage>
{

  String selectedWing = 'A';
  TextEditingController FirstName = TextEditingController();
  TextEditingController LastName = TextEditingController();
  TextEditingController Email = TextEditingController();
  TextEditingController MobileNo = TextEditingController();
  TextEditingController Password = TextEditingController();

  GenderSelect _gender = GenderSelect.Male;
  final _formKey = GlobalKey<FormState>();


  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Form(
        key: _formKey,
        // autovalidateMode: AutovalidateMode.onUserInteraction,
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,

          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 70,),

              Text("Hey there,", style: TextStyle(fontSize: 15, color: Colors.white),),

              SizedBox(height: 10,),

              Text("Create an Account", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),),

              SizedBox(height: 15,),

              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.all(7.0),
                padding: EdgeInsets.only(bottom: 2, left: 10),

                width: 300,
                height: MediaQuery.sizeOf(context).height*0.07,

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  textAlign: TextAlign.start,
                  controller: FirstName,
                  decoration: InputDecoration(
                    border: InputBorder.none,

                    icon: Icon(Icons.perm_identity_outlined, color: Colors.black,),
                    hintText: "First Name",
                    contentPadding: EdgeInsets.symmetric(vertical: 7),

                  ),
                  keyboardType: TextInputType.text,
                  onFieldSubmitted: (value) {

                  },
                  validator: (value)
                  {
                    if(value!.isEmpty)
                    {
                      return "Please Enter FirstName";
                    }
                    return null;
                  },
                ),
              ),

              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.all(7.0),
                padding: EdgeInsets.only(bottom: 2, left: 10),

                width: 300,
                height: MediaQuery.sizeOf(context).height*0.07,

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  textAlign: TextAlign.start,
                  controller: LastName,
                  decoration: InputDecoration(
                    border: InputBorder.none,

                    icon: Icon(Icons.person_outline_outlined, color: Colors.black,),
                    hintText: "Last Name",
                    contentPadding: EdgeInsets.symmetric(vertical: 7),

                  ),
                  keyboardType: TextInputType.text,
                  onFieldSubmitted: (value) {

                  },
                  validator: (value)
                  {
                    if(value!.isEmpty)
                    {
                      return "Please Enter LastName";
                    }
                    return null;
                  },
                ),
              ),

              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.all(7.0),
                padding: EdgeInsets.only(bottom: 2, left: 10),

                width: 300,
                height: MediaQuery.sizeOf(context).height*0.07,

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  children: [
                    Icon(Icons.person_outline_outlined, color: Colors.black,),

                    SizedBox(width: 16),

                    Text("Gender", style: TextStyle(color: Colors.black87),),

                    SizedBox(width: 4),

                    Flexible(
                      child: Radio(
                        value: GenderSelect.Male,
                        groupValue: _gender,
                        onChanged: (GenderSelect? value) {
                          setState(()
                          {
                            _gender = value!;

                          });

                        },
                      ),
                    ),

                    Text("Male"),

                    Flexible(
                      child: Radio(
                        value: GenderSelect.Female,
                        groupValue: _gender,
                        onChanged: (GenderSelect? value) {

                          setState(() {

                            _gender = value!;


                          });
                        },
                      ),
                    ),
                    Text("Female"),
                  ],
                ),
              ),

              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.all(7.0),
                padding: EdgeInsets.only(bottom: 2, left: 10),
                width: 300,
                height: MediaQuery.sizeOf(context).height*0.07,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  children: [
                    Icon(Icons.home_outlined, color: Colors.black,),
                    SizedBox(width: 16),
                    Text("Address(Wing)", style: TextStyle(color: Colors.black87),),
                    SizedBox(width: 4),
                    DropdownButton<String>(
                      value: selectedWing,
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedWing = newValue!;
                        });
                      },
                      items: ['A', 'B', 'C', 'D', 'E', 'F']
                          .map((wing) => DropdownMenuItem<String>(
                        value: wing,
                        child: Text(wing),
                      ))
                          .toList(),
                    ),
                  ],
                ),
              ),


              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.all(7.0),
                padding: EdgeInsets.only(bottom: 2, left: 10),

                width: 300,
                height: MediaQuery.sizeOf(context).height*0.07,

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  textAlign: TextAlign.start,
                  controller: Email,
                  decoration: InputDecoration(
                    border: InputBorder.none,

                    icon: Icon(Icons.email_outlined, color: Colors.black,),
                    hintText: "Email",
                    contentPadding: EdgeInsets.symmetric(vertical: 7),

                  ),
                  keyboardType: TextInputType.emailAddress,
                  onFieldSubmitted: (value) {

                  },
                  validator: (value)
                  {
                    if(value!.isEmpty || !RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value))
                    {
                      return "Please Enter a valid Email";
                    }
                    return null;
                  },
                ),
              ),

              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.all(7.0),
                padding: EdgeInsets.only(bottom: 2, left: 10),

                width: 300,
                height: MediaQuery.sizeOf(context).height*0.07,

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  textAlign: TextAlign.start,
                  controller: MobileNo,
                  decoration: InputDecoration(
                    border: InputBorder.none,

                    icon: Icon(Icons.phone_outlined, color: Colors.black,),
                    hintText: "Mobile No",
                    contentPadding: EdgeInsets.symmetric(vertical: 7),

                  ),
                  keyboardType: TextInputType.number,
                  onFieldSubmitted: (value) {

                  },
                  validator: (value)
                  {
                    if(value!.isEmpty || !RegExp(r"^\d{10}$").hasMatch(value))
                    {
                      return "Please Enter Valid Mobileno";
                    }
                    return null;
                  },
                ),
              ),

              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.all(7.0),
                padding: EdgeInsets.only(bottom: 2, left: 10),

                width: 300,
                height: MediaQuery.sizeOf(context).height*0.07,

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  textAlign: TextAlign.start,
                  controller: Password,
                  obscureText: true,
                  decoration: InputDecoration(
                    border: InputBorder.none,

                    icon: Icon(Icons.lock_outline, color: Colors.black,),
                    hintText: "Password",
                    contentPadding: EdgeInsets.symmetric(vertical: 7),

                  ),
                  keyboardType: TextInputType.text,
                  onFieldSubmitted: (value) {

                  },
                  validator: (value)
                  {
                    if(value!.isEmpty || !RegExp(r"^(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$").hasMatch(value))
                    {
                      return "Please Enter Password with 8 character, one Uppercase, one Symbol";
                    }
                    return null;
                  },
                ),
              ),

              SizedBox(height: 20),

              TextButton(
                onPressed: ()
                {
                  setState(() {
                    print("1");
                    if(_formKey.currentState!.validate())
                    {
                      print("Clicked");
                      var url=Uri.parse("https://begrimed-executions.000webhostapp.com/digital_society/register/register_insert.php");
                      String Gender = _gender == GenderSelect.Male ? "Male" : "Female";
                      String Address = selectedWing;
                      http.post(url,

                          body:
                          {

                            "FirstName": FirstName.text.toString(),
                            "LastName": LastName.text.toString(),
                            "Gender": Gender.toString(),
                            "Address": Address.toString(),
                            "Email": Email.text.toString(),
                            "MobileNo": MobileNo.text.toString(),
                            "Password": Password.text.toString(),

                          }

                      );
                      print("yes");

                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => MainScreen()));

                      print(FirstName.text.toString());
                      print(LastName.text.toString());
                      print(Gender.toString());
                      print(Address.toString());
                      print(Email.text.toString());
                      print(MobileNo.text.toString());
                      print(Password.text.toString());

                    }
                  });


                },
                style: TextButton.styleFrom(
                  primary: Colors.white,
                  backgroundColor: Colors.blue,
                ),

                child: Container(
                  alignment: Alignment.center,

                  width: 200,
                  height: 30,


                  child: Text("Register",style: TextStyle(fontSize: 20, color: Colors.white,),),
                  // Text Color
                ),
              ),

              SizedBox(height: 20),

              Text("Or Register With", style: TextStyle(fontSize: 15, color: Colors.white),),

              SizedBox(height: 20),

              Row(
                children: [
                  SizedBox(width: 20),
                  ElevatedButton.icon(
                    onPressed: ()
                    {
                      facebook();
                    },
                    icon: Image.asset("images/facebook.png", height: 20, width: 20,),
                    label: Text(" Facebook", style: TextStyle(color: Colors.white),),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.only(left: 30, right: 30, top: 10, bottom: 10),
                    ),
                  ),
                  SizedBox(width: 10),

                  ElevatedButton.icon(
                    onPressed: ()
                    {
                      google();
                    },
                    icon: Image.asset("images/google.png", height: 20, width: 20),
                    label: Text("Google", style: TextStyle(color: Colors.white),),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.only(left: 40, right: 40,top: 10, bottom: 10),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    onPressed: ()
                    {
                     print("Login button pressed");
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Text("Already have an account? Login", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),),),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void facebook() async
  {

    var url = Uri.parse("https://www.facebook.com/");
    if (await canLaunchUrl(url))
    {
      await launchUrl(url);
    }
    else
    {
      throw 'Could not launch $url';
    }
  }

  void google() async
  {
    var url = Uri.parse("https://www.google.com/");
    if (await canLaunchUrl(url))
    {
      await launchUrl(url);
    }
    else
    {
      throw 'Could not launch $url';
    }
  }
}