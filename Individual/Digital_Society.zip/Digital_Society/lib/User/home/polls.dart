import 'package:flutter/material.dart';
import 'package:pie_chart/pie_chart.dart';

class polls extends StatefulWidget {
  const polls({super.key});

  @override
  State<polls> createState() => _pollsState();
}

class _pollsState extends State<polls>
{
 Map<String, double> dataMap = {
   "Event": 18.25,
   "WorkerSalary": 28.75,
   "Bills": 32.08,
   "Others": 19.92,
 };

 List<Color> color = [
   const Color(0xffcc99ff),
   const Color(0xff33cccc),
   const Color(0xffff99cc),
   const Color(0xffb3ccff),


 ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Polls", style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.deepPurple,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("images/background_image.jpg"),
                fit: BoxFit.cover,
                repeat: ImageRepeat.repeat
              )
            ),
          ),
          Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 25,),
                Text("Used Expenses:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18,), textAlign: TextAlign.left,),
                SizedBox(height: 70,),
                Container(
                  child: PieChart(dataMap: dataMap,
                  colorList: color,
                    chartRadius: MediaQuery.of(context).size.width/2,
                    centerText: "Polls",
                    ringStrokeWidth: 24,

                    animationDuration: const Duration(seconds: 3),
                    chartValuesOptions: const ChartValuesOptions(
                      showChartValues: true,
                      showChartValuesOutside: true,
                      showChartValuesInPercentage: true,
                      showChartValueBackground: false,
                    ),
                    legendOptions: const LegendOptions(
                      showLegends: true,
                      legendShape: BoxShape.rectangle,
                      legendTextStyle: TextStyle(fontSize: 15),
                      legendPosition: LegendPosition.bottom,
                      showLegendsInRow: false,
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}