import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class visitors extends StatefulWidget {
  @override
  visitorsState createState() => visitorsState();
}

class visitorsState extends State<visitors> {
  late List list;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Visitors",
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('images/background_image.jpg'),
                repeat: ImageRepeat.repeat,
                fit: BoxFit.fill,
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("If any of your Guest will come, \n You will get a call \n"
                    " Accept the call \n then only Guest can come.",
                  style: TextStyle(color: Colors.deepPurple, fontSize: 20, fontWeight: FontWeight.bold),)
              ],
            ),
          ),
        ],
      ),
    );
  }
}