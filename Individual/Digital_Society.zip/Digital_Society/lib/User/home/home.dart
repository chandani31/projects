import 'package:app_settings/app_settings.dart';
import 'package:digital_society1/User/constants.dart';
import 'package:digital_society1/User/home/Parking/Parking.dart';
import 'package:digital_society1/User/home/SOS.dart';
import 'package:digital_society1/User/home/events.dart';
import 'package:digital_society1/User/home/polls.dart';
import 'package:digital_society1/User/home/visitors.dart';
import 'package:digital_society1/User/login/login.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../Admin/home/Events/adminEvents.dart';
import 'Complaints.dart';
import 'Events/events.dart';
import 'NoticeBoard.dart';
import 'ServiceProviders.dart';
import 'members.dart';

class homePage extends StatefulWidget {
  const homePage({super.key});

  @override
  State<homePage> createState() => _homePageState();
}

class _homePageState extends State<homePage> {
  int _selectedIndex = 0;
  List<String> names =
  [
    membersName,
    noticeBoardName,
    // name3,
    eventsName,
    visitorsName,
    serviceProvidersName,
    // name7,
    parkingName,
    sosName,
    complaintsName,
    // name11,
    pollsName,
  ];

  List<String> icons =
  [
    memberIcon,
    noticeBoardIcon,
    // icon3,
    eventsIcon,
    visitorsIcon,
    serviceProvidersIcon,
    // icon7,
    parkingIcon,
    sosIcon,
    complaintsIcon,
    // icon11,
    pollsIcon,
  ];

  late String MobileNo;
  late SharedPreferences logindata;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initial();
  }

  void initial() async {
    logindata = await SharedPreferences.getInstance();
    setState(() {
      MobileNo = logindata.getString('MobileNo') ?? '';
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      appBar: AppBar(
        title: Text("Smart Society", style: TextStyle(color: Colors.white),),
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.deepPurple,
        actions: [
          IconButton(
              onPressed: () {
                logindata.setBool('login', true);
                Navigator.pushReplacement(context,
                    new MaterialPageRoute(builder: (context) => LoginPage()));
              }, icon: Icon(Icons.logout, color: Colors.white,)),
        ],
      ),

      drawer: Drawer(surfaceTintColor: Colors.white,
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            const UserAccountsDrawerHeader(
              decoration: BoxDecoration(color: Colors.white),
              accountName: Text("Email",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              currentAccountPicture: CircleAvatar(
                radius: 80.0, // Adjust the size as needed
                backgroundImage: AssetImage("images/members.png"),
                backgroundColor: Colors.deepPurple,
              ),
              accountEmail: Text("Email"),
            ),
            ListTile(
              leading: Icon(
                Icons.photo_library_rounded,
                color: Colors.black,
              ),
              title: const Text(
                'Images', style: TextStyle(color: Colors.black),),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) =>
                    events()));
              },
            ),
            ListTile(
              leading: Icon(
                Icons.archive,
                color: Colors.black,
              ),
              title: const Text(
                'Archieved', style: TextStyle(color: Colors.black),),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Nothing is Archieved")));
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.delete,
                color: Colors.black,
              ),
              title: const Text(
                'Trash', style: TextStyle(color: Colors.black),),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Nothing is Deleted")));
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.settings,
                color: Colors.black,
              ),
              title: const Text(
                'Settings', style: TextStyle(color: Colors.black),),
              onTap: () {
                AppSettings.openAppSettings();
                Navigator.pop(context); // Close the drawer if needed
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(0),
              child: Image.asset("images/home.jpg"),
            ),
            SizedBox(height: 5,),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  color: Colors.deepPurple,
                  child: GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 7.0,
                      mainAxisSpacing: 7.0,
                      childAspectRatio: 0.9,
                    ),
                    itemCount: icons.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(
                        onTap: () async
                        {
                          switch (index) {
                            case 0:
                              if (names[index] == membersName &&
                                  icons[index] == memberIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => Members()));
                              }
                              break;
                            case 1:
                              if (names[index] == noticeBoardName &&
                                  icons[index] == noticeBoardIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => NoticeBoard()));
                              }
                              break;
                            case 2:
                              if (names[index] == eventsName &&
                                  icons[index] == eventsIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => events()));
                              }
                              break;
                            case 5:
                              if (names[index] == parkingName &&
                                  icons[index] == parkingIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => Parking()));
                              }
                              break;
                            case 4:
                              if (names[index] == serviceProvidersName &&
                                  icons[index] == serviceProvidersIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => ServiceProviders()));
                              }
                              break;
                            case 3:
                              if (names[index] == visitorsName &&
                                  icons[index] == visitorsIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => visitors()));
                              }
                              break;
                            case 7:
                              if (names[index] == complaintsName &&
                                  icons[index] == complaintsIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => Complaints()));
                              }
                              break;
                            case 8:
                              if (names[index] == pollsName &&
                                  icons[index] == pollsIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => polls()));
                              }
                            case 6:
                              if (names[index] == sosName &&
                                  icons[index] == sosIcon) {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => SOS()));
                              }

                            default:
                            // Handle default case if needed
                          }
                        },

                        child: Column(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4.0),
                              child: Container(
                                alignment: Alignment.center,
                                height: 120,
                                width: 200,
                                color: Colors.white,
                                child: Center(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment
                                          .center,
                                      children: [
                                        Container(
                                          height: 60,
                                          // Adjust the height of the image
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: AssetImage(icons[index]),
                                              fit: BoxFit
                                                  .contain, // Adjust the fit to contain the image within the container
                                            ),
                                          ),
                                        ),
                                        Text(names[index],
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    )
                                ),
                              ),
                            ),
                          ],
                        ),
                        // Replace with your actual item widget
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void openAppSettings() async {
    if (await canLaunch('package:com.android.settings')) {
      await launch('package:com.android.settings');
    } else {
      print('Could not open app settings');
    }
  }
}