import 'package:digital_society1/Admin/home/adminComplaints.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Complaints extends StatefulWidget {
  const Complaints({super.key});

  @override
  State<Complaints> createState() => _ComplaintsState();
}

class _ComplaintsState extends State<Complaints>
{
  TextEditingController complaints = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Complaints", style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.deepPurple,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('images/background_image.jpg'),
            fit: BoxFit.cover,
          )
        ),
        child: Center(
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 150,),
              Container(
                height: 200,
                width: 350,
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.deepPurple,
                    width: 2.0,
                  ),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextField(
                  controller: complaints,
                  decoration: InputDecoration(
                    labelText: "Enter Message (with Name and FlatNo)",
                    labelStyle: TextStyle(color: Colors.deepPurple),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.only(left: 20, top: 20, right: 20, bottom: 10),
                  ),
                  keyboardType: TextInputType.multiline,
                  maxLines: null,
                  expands: true,
                ),
              ),

              SizedBox(height: 10,),

              ElevatedButton(
                onPressed: ()
                {
                  setState(() {
                    print("1");
                    print("Clicked");
                    var url = Uri.parse(
                        "https://begrimed-executions.000webhostapp.com/digital_society/complaints/insert.php");
                    http.post(url,

                        body:
                        {
                          "complaints": complaints.text.toString(),
                        }
                        );
                    complaints.text = "";
                    print("yes");

                    print(complaints.text.toString());
                  }
                  );
                  // Navigator.push(context, MaterialPageRoute(builder: (context) => adminComplaints()));
                },
                child: Text("Send", style: TextStyle(color: Colors.white),),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
