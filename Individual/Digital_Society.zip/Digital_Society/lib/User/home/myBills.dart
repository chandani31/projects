// import 'dart:convert';
// import 'dart:math';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class ProfilePage extends StatefulWidget {
//   const ProfilePage({Key? key});
//
//   @override
//   State<ProfilePage> createState() => _ProfilePageState();
// }
//
// class _ProfilePageState extends State<ProfilePage> {
//   late SharedPreferences logindata;
//   String MobileNo = '';
//   late List<dynamic> billDetails;
//   bool dataLoaded = false;
//
//   @override
//   void initState() {
//     super.initState();
//     retrieveMobileNo();
//   }
//
//   Future<void> retrieveMobileNo() async {
//     logindata = await SharedPreferences.getInstance();
//     MobileNo = logindata.getString('mob') ?? '';
//     setState(() {});
//     if (!dataLoaded) {
//       await getdetail();
//     }
//   }
//
//   Future<void> getdetail() async {
//     try {
//       var response = await http.get(
//         Uri.parse(
//           "https://begrimed-executions.000webhostapp.com/digital_society/my_bills/view.php?mob=$MobileNo",
//         ),
//       );
//
//       if (response.statusCode == 200) {
//         setState(() {
//           print('Response body: ${response.body}');
//           billDetails = jsonDecode(response.body);
//           print('Decoded JSON: $billDetails');
//           dataLoaded = true;
//         });
//       } else {
//         print(
//           'Failed to load bill details. Status code: ${response.statusCode}',
//         );
//         print('Response body: ${response.body}');
//       }
//     } catch (e) {
//       print('Error: $e');
//     }
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(
//           "My Bills",
//           style: TextStyle(color: Colors.white),
//         ),
//         backgroundColor: Colors.deepPurple,
//         iconTheme: IconThemeData(color: Colors.white),
//       ),
//       body: Stack(
//         children: [
//           Container(
//             decoration: BoxDecoration(
//               image: DecorationImage(
//                 image: AssetImage('images/background_image.jpg'),
//                 fit: BoxFit.cover,
//                 repeat: ImageRepeat.repeat,
//               ),
//             ),
//           ),
//           // Center(
//           //   child: FutureBuilder<void>(
//           //     future: getdetail(),
//           //     builder: (ctx, ss) {
//           //       if (ss.hasData) {
//           //         return Items(list: billDetails[0]);
//           //       }
//           //       if (ss.hasError) {
//           //         print('Network Not Found');
//           //       }
//           //
//           //       return CircularProgressIndicator();
//           //     },
//           //   ),
//           // ),
//           // Center(
//           //   child: FutureBuilder<void>(
//           //     future: _retrieveMobileNoandDetails(), // Call retrieveMobileNo here
//           //     builder: (ctx, ss) {
//           //       if (ss.connectionState == ConnectionState.waiting) {
//           //         return CircularProgressIndicator();
//           //       } else if (ss.hasError) {
//           //         return Text('Error: ${ss.error}');
//           //       } else {
//           //         return dataLoaded
//           //             ? Items(list: billDetails.isNotEmpty ? billDetails[0] : null)
//           //             : CircularProgressIndicator();
//           //       }
//           //     },
//           //   ),
//           // ),
//           Center(
//             child: dataLoaded
//                 ? Items(list: billDetails.isNotEmpty ? billDetails[0] : null)
//                 : CircularProgressIndicator(),
//           ),
//         ],
//       ),
//     );
//   }
// }
//
// class Items extends StatelessWidget {
//   Map<String, dynamic>?  list;
//
//   Items({required this.list});
//
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         SizedBox(height: 50,),
//         Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: Text(
//             "Registered Mobile: ${list?['MobileNo'] ?? 'N|A'}",
//             style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.deepPurple),
//           ),
//         ),
//         SizedBox(height: 20,),
//         Expanded(
//           child: ListView.builder(
//             itemCount: list != null ? 1 : 0,
//             itemBuilder: (ctx, i) {
//               return Container(
//                 padding: EdgeInsets.all(15),
//                 margin: EdgeInsets.only(top: 10, left: 15, right: 15, bottom: 10),
//                 height: MediaQuery.of(context).size.height*0.24,
//                 width: MediaQuery.of(context).size.width*0.3,
//                 decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(15),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.deepPurple.withOpacity(0.7),
//                       spreadRadius: 3,
//                       blurRadius: 3,
//                       offset: Offset(0, 2),
//                     ),
//                   ],
//                 ),
//                 child: ListTile(
//                   title: Text("Name : ${list?['Name'] ?? 'N/A'}", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
//                   subtitle: Column(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text("Address(Wing) : ${list?['Address'] ?? 'N/A'}", style: TextStyle(color: Colors.white, fontSize: 16)),
//                           Text("Email : ${list?['Email'] ?? 'N/A'}", style: TextStyle(color: Colors.white, fontSize: 16)),
//                           Text("MobileNo : ${list?['MobileNo'] ?? 'N/A'}", style: TextStyle(color: Colors.white, fontSize: 16)),
//                           Text("Payment : ${list?['Payment'] ?? 'N/A'}", style: TextStyle(color: Colors.white, fontSize: 16)),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//               );
//             },
//           ),
//         ),
//       ],
//     );
//   }
// }
