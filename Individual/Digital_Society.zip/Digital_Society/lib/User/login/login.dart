import 'dart:convert';
import 'package:digital_society1/Admin/home/adminHome.dart';
import 'package:digital_society1/Admin/home/admin_bottom_navigation/adminMainScreen.dart';
import 'package:digital_society1/User/home/home.dart';
import 'package:digital_society1/User/register/register.dart';
import 'package:digital_society1/main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;

import '../bottom_navigation/mainScreen.dart';


class LoginPage extends StatefulWidget
{
  @override
  LoginState createState() => LoginState();


}

class LoginState extends State<LoginPage>
{

  final _formKey = GlobalKey<FormState>();
  String MobileNo = '';
  String Password = '';
  late SharedPreferences logindata;

  late bool newuser;
  var isLoading = false;

  @override
  void initState() {
    super.initState();
    check_if_already_login();
  }

  void check_if_already_login() async {
    logindata = await SharedPreferences.getInstance();
    newuser = (logindata.getBool('login') ?? true);
    print(newuser);

    if (newuser == false) {
      String? storedMobileNo = logindata.getString('mob');
      String? storedPassword = logindata.getString('Pass');
      // Check if the logged-in user is an admin
      // bool isAdmin = logindata.getBool('isAdmin') ?? false;
      if (storedMobileNo == "9987654321" && storedPassword == "ABC@123")
      {
        // Navigate to AdminMainScreen
        // logindata.setBool('isAdmin', true);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => adminMainScreen()),
        );
      }
      else
      {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => MainScreen()),
        );
      }
    }
  }



  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          // autovalidateMode: AutovalidateMode.onUserInteraction,
          child: Center(
            child: Column(
              children: [
        
                SizedBox(height: 120),
        
                Text("Hey there,", style: TextStyle(fontSize: 15, color: Colors.white),),
        
                SizedBox(height: 15),
        
                Text("Welcome Back", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),),
        
                SizedBox(height: 15),
        
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.all(7.0),
                  padding: EdgeInsets.only(bottom: 2, left: 10),
        
                  width: 300,
                  height: MediaQuery.sizeOf(context).height*0.07,
        
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: TextFormField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
        
                      icon: Icon(Icons.call_outlined, color: Colors.black,),
                      hintText: "Mobile No",
                      contentPadding: EdgeInsets.symmetric(vertical: 7),
                    ),
        
                    keyboardType: TextInputType.number,
                    onSaved: (value) {
                      MobileNo = value!;
                    },
                    validator: (value) {
                      MobileNo = value!;
                      if (value == null || value.isEmpty)
                      {
                        return 'Please enter a phone number';
                      }
        
                      return null;
                    },
                  ),
                ),
        
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.all(7.0),
                  padding: EdgeInsets.only(bottom: 2, left: 10),
        
                  width: 300,
                  height: MediaQuery.sizeOf(context).height*0.07,
        
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: TextFormField(
                    textAlign: TextAlign.start,
        
                    decoration: InputDecoration(
                      border: InputBorder.none,
        
                      icon: Icon(Icons.lock_outline, color: Colors.black,),
                      hintText: "Password",
                      contentPadding: EdgeInsets.symmetric(vertical: 7),
        
                    ),
        
                    keyboardType: TextInputType.text,
                    obscureText: true,
                    onSaved: (value) {
                      Password = value!;
                    },
                    validator: (value) {
                      Password = value!;
                      if (value == null || value.isEmpty)
                      {
                        return 'Please enter a Password';
                      }
        
                      return null;
                    },
        
                  ),
                ),
        
                SizedBox(height: 20),
        
                TextButton(
                  onPressed: () async
                  {
                    var url = "https://begrimed-executions.000webhostapp.com/digital_society/login/login_view.php";
                    var response = await http.post(Uri.parse(url), body: {
                      "MobileNo": MobileNo.toString(),
                      "Password": Password.toString(),
                    });
                    var data = json.decode(response.body);

                    if (data == 0) {
                      print("1");
                      final snackBar = SnackBar(
                        content: Text(
                          'Something Is Wrong...',
                          style: TextStyle(),
                        ),
                        duration: Duration(seconds: 5),
                      );

                    }  else {
                      print("2");
                      if (MobileNo == "9987654321" && Password == "ABC@123")
                      {
                        // Navigate to AdminMainScreen
                        // logindata.setBool('isAdmin', true);
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => adminMainScreen()),
                        );
                      }
                     else
                       {
                         Navigator.pushReplacement(
                           context,
                           MaterialPageRoute(builder: (context) => MainScreen()),
                         );
                       }
                    }

                    final isValid = _formKey.currentState!.validate();
                    if (!isValid) {
                      return;
                    } else {
                      _formKey.currentState?.save();
                      String mob = MobileNo;
                      String Pass = Password;
                      if (mob != '' && Pass != '') {
                        print('success');
                        logindata.setBool('login', false);
                        logindata.setString('mob', mob);
                        logindata.setBool('login', false);
                        logindata.setString('Pass', Pass);
                      }
                    }
                  },
                  style: TextButton.styleFrom(
                    primary: Colors.white,
                    backgroundColor: Colors.blue,
                  ),
        
                  child: Container(
                    alignment: Alignment.center,
        
                    width: 200,
                    height: 30,
        
        
                    child: Text("Login",style: TextStyle(fontSize: 20, color: Colors.white,),),
                    // Text Color
                  ),
                ),
        
                SizedBox(height: 20),
        
                Text("Or Continue With", style: TextStyle(fontSize: 15, color: Colors.white),),
        
                SizedBox(height: 20),
        
                Row(
                  children: [
                    SizedBox(width: 20),
                    ElevatedButton.icon(
                      onPressed: ()
                      {
                        facebook();
                      },
                      icon: Image.asset("images/facebook.png", height: 20, width: 20,),
                      label: Text(" Facebook", style: TextStyle(color: Colors.white),),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.blueGrey,
                        padding: EdgeInsets.only(left: 30, right: 30, top: 10, bottom: 10),
                      ),
                    ),
                    SizedBox(width: 10),
        
                    ElevatedButton.icon(
                      onPressed: ()
                      {
                        google();
                      },
                      icon: Image.asset("images/google.png", height: 20, width: 20),
                      label: Text("Google", style: TextStyle(color: Colors.white),),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.blueGrey,
                        padding: EdgeInsets.only(left: 40, right: 40,top: 10, bottom: 10),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
        
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                      onPressed: ()
                      {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => RegistrationPage()));
                      },
                      child: Text("Don't have an account yet? Register", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),),),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void facebook() async
  {
    var url = Uri.parse("https://www.facebook.com/");
    if (await canLaunchUrl(url))
    {
      await launchUrl(url);
    }
    else
    {
      throw 'Could not launch $url';
    }
  }

  void google() async
  {
    var url = Uri.parse("https://www.google.com/");
    if (await canLaunchUrl(url))
    {
      await launchUrl(url);
    }
    else
    {
      throw 'Could not launch $url';
    }
  }
}

