import 'package:digital_society1/User/bottom_navigation/profilePage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../Admin/home/adminHome.dart';
import '../home/home.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen>
{
  int _selectedIndex = 0;

  List<Widget?> _pages = [null, null]; // Initialize with null values initially

  @override
  void initState() {
    super.initState();
    _selectedIndex = 0;
    _loadPages();
  }

  void _loadPages() async {
    // var profilePageState = ProfilePageState(); // Instantiate ProfilePageState
    // await profilePageState.getdetail();  // Load the data for ProfilePage

    // Once data is loaded, update the _pages list with the actual widgets
    setState(() {
      _pages = [
        homePage(),
        ProfilePage(),
      ];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex] ?? SizedBox(),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.deepPurple,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.grey,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Profile",
          ),
        ],
      ),
    );
  }

  void _onItemTapped(int value) {
    setState(() {
      _selectedIndex = value;
    });
  }

}
